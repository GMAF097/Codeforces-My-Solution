        #include "bits/stdc++.h"
        using ll = long long int;
        //khub e baler approach
        using namespace std;
        int main()
        {
            int t; cin >> t;
            if(t % 2 == 0 && t > 2) cout << "YES\n";
            else cout << "NO\n";
        }