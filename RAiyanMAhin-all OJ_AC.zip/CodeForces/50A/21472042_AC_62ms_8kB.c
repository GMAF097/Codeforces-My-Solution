    #include<stdio.h>
    int main()
    {
        int M,N;
        scanf("%d%d",&M,&N);
        printf("%d\n",(M*N)/2);
    }