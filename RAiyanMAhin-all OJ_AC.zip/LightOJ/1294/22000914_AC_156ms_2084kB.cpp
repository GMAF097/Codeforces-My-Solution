    //RAIYAN_MAHIN
    #include<bits/stdc++.h>
    using namespace std;
    typedef long long int ll;
    #define PI acos(-1)
    int main()
    {
        int t; cin>>t;
        for(int d=1;d<=t;d++)
        {
            ll n,m,k,s; cin>>n>>m;
            k=n/2*m; s=m*m*k;
            printf("Case %d: %lld\n",d,k);




            }

        }

